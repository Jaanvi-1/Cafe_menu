from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import MenuItem
from .serializers import MenuItemSerializer

class CafeMenuSearch(APIView):
    def get(self, request, keyword):
        try:
            menu_items = MenuItem.objects.filter(name__icontains=keyword)
            serializer = MenuItemSerializer(menu_items, many=True)
            return Response(serializer.data)
        except MenuItem.DoesNotExist:
            return Response({"message": "Menu item not found"}, status=status.HTTP_404_NOT_FOUND)
